module instruction_memory(

    input  [31:0] PC_In,
    output [31:0] Instruction_Out

);

    // 256 x 32-bit Instruction Memory
    reg [31:0] instruction_mem [0:255];

    integer i;

    initial begin

        // Initialize all memory locations to NOP
        for(i = 0; i < 256; i = i + 1)
            instruction_mem[i] = 32'h00000013;   // NOP

        // ==================================================
        // Program Instructions
        // ==================================================

        // // Address 0x00000000 : addi x1, x0, 10
        // instruction_mem[0] = 32'h00A00093;

        // // Address 0x00000004 : addi x2, x0, 20
        // instruction_mem[1] = 32'h01400113;

        // // Address 0x00000008 : add x3, x1, x2
        // instruction_mem[2] = 32'h002081B3;

        // // Address 0x0000000C : sub x4, x2, x1
        // instruction_mem[3] = 32'h40110233;

        // // Address 0x00000010 : xor x5, x1, x2
        // instruction_mem[4] = 32'h0020C2B3;

        // // Address 0x00000014 : and x6, x1, x2
        // instruction_mem[5] = 32'h0020F333;

        // // Address 0x00000018 : ori x7, x1, 5
        // instruction_mem[6] = 32'h0050E393;

        // // Address 0x0000001C : andi x8, x2, 15
        // instruction_mem[7] = 32'h00F17413;

        // // Address 0x00000020 : xori x9, x1, 3
        // instruction_mem[8] = 32'h0030C493;

//==================================================
// Program Instructions (Forwarding Test)
//==================================================

// addi x1, x0, 10
instruction_mem[0] = 32'h00A00093;

// addi x2, x0, 20
instruction_mem[1] = 32'h01400113;

// add x3, x1, x2
instruction_mem[2] = 32'h002081B3;

// add x4, x3, x1
instruction_mem[3] = 32'h00118233;

// add x5, x4, x2
instruction_mem[4] = 32'h002202B3;

// add x6, x5, x3
instruction_mem[5] = 32'h00328333;
    end

    // Instruction Fetch
    assign Instruction_Out = instruction_mem[PC_In[9:2]];

endmodule