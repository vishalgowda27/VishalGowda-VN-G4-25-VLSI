`timescale 1ns / 1ps

module tb_PIPELINE;

reg clk;
reg rst;

wire [31:0] DM_Addr_Out;
wire [31:0] DM_WrData_Out;
wire [3:0]  DM_WrMask_Out;
wire        DM_WrEn_Out;
wire [31:0] PC_Out;
integer cycle = 0;
RISCV_PIPELINE_TOP dut(

    .clk(clk),
    .rst(rst),

    .DM_Addr_Out(DM_Addr_Out),
    .DM_WrData_Out(DM_WrData_Out),
    .DM_WrMask_Out(DM_WrMask_Out),
    .DM_WrEn_Out(DM_WrEn_Out),

    .PC_Out(PC_Out)

);

// Clock Generation
always #5 clk = ~clk;

// Reset
initial begin

    clk = 0;
    rst = 1;

    $dumpfile("pipeline.vcd");
    $dumpvars(0, tb_PIPELINE);

    #20;
    rst = 0;

    #200;

    $finish;

end
always @(posedge clk) begin
#1;
$display("Reg_WrEn_W : %b", dut.Reg_WrEn_W);

$display("REG x1 : %h", dut.RF_INST.my_regs[1]);
$display("REG x2 : %h", dut.RF_INST.my_regs[2]);
$display("REG x3 : %h", dut.RF_INST.my_regs[3]);
$display("REG x4 : %h", dut.RF_INST.my_regs[4]);
    if (!rst) begin
        cycle = cycle + 1;

        $display("\n========================================================");
        $display("Cycle : %0d", cycle);
        $display("PC : %h", dut.PC_F);

        $display("rs1_E         : %0d", dut.rs1_E);
        $display("rs2_E         : %0d", dut.rs2_E);

        $display("Src_Data1_E   : %h", dut.Src_Data1_E);
        $display("Src_Data2_E   : %h", dut.Src_Data2_E);

        $display("ForwardA      : %b", dut.ForwardA);
        $display("ForwardB      : %b", dut.ForwardB);

        $display("ForwardA_Data : %h", dut.ForwardA_Data);
        $display("ForwardB_Data : %h", dut.ForwardB_Data);

        $display("Imm_Data_E    : %h", dut.Imm_Data_E);
        $display("ALU_Src_E     : %b", dut.ALU_Src_E);

        $display("ALU_B         : %h", dut.ALU_B);
        $display("ALU_Result    : %h", dut.ALU_Result);

        $display("========================================================");
        $display("Instruction_D : %h", dut.Instruction_D);

$display("rs1           : %0d", dut.rs1);
$display("rs2           : %0d", dut.rs2);

$display("Src_Data1     : %h", dut.Src_Data1);
$display("Src_Data2     : %h", dut.Src_Data2);

$display("Writeback     : x%0d = %h",
         dut.rd_W,
         dut.Writeback_Data);
    end


end
endmodule